package com.Hashmap;

import java.util.Enumeration;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ConcurrentHashmapdemo {

	public static void main(String[] args) {
		ConcurrentHashMap<String,Integer> chm=new ConcurrentHashMap<String,Integer>();
		chm.put("Afreen",100);
		chm.put("abhi",40);
		chm.put("amruta",60);
		chm.put("anu",50);
		chm.put("aish",70);
		System.out.println(chm);
		System.out.println(chm.containsValue(100));
		System.out.println(chm.computeIfAbsent("Api", k-> 30+40));//adds the record to the map
		System.out.println(chm.computeIfAbsent("abhi", k-> 60+40));
		System.out.println(chm.computeIfPresent("anu", (key , val) -> val +100));
		System.out.println(chm.computeIfPresent("aish", (key , val) -> val +50));
		System.out.println(chm.mappingCount());
		System.out.println(chm);
		Set set=chm.entrySet();
		System.out.println(set);
		Enumeration en=chm.elements();
		while(en.hasMoreElements())
		{
			System.out.println(en.nextElement());
		}
		
		
		
		
		
	}

}
