package com.Employee;

public class Adult implements Comparable<Ship60> {
	private int no;
	private int adage;
	private String name;
	private int ticket;

	public Adult(int no, int adage, String name, int ticket) {
		super();
		this.no = no;
		this.adage = adage;
		this.name = name;
		this.ticket = ticket;
	}

	@Override
	public int compareTo(Ship60 obj) {
		{
			if (adage == obj.adage)
				return 0;
			else if (adage > obj.adage)
				return 1;
			else
				return -1;
		}
	}

}
