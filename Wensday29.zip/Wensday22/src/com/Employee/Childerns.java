package com.Employee;

public class Childerns implements Comparable<Ship60>  {
	int no,cldage;
	String name;
	int ticket;
	public Childerns(int no, int cldage, String name, int ticket) {
		super();
		this.no = no;
		this.cldage = cldage;
		this.name = name;
		this.ticket = ticket;
	}
	@Override
	public int compareTo(Ship60 obj) {
		{
			if (cldage == obj.clddage)
				return 0;
			else if (clddage > obj.clddage)
				return 1;
			else
				return -1;
		}
	}
	
	
}
