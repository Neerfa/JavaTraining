package com.Employee;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

import Wednesday.Employee58;
import Wednesday.EmployeeAge;
import Wednesday.Student;

public class Employeemain {

	public static void main(String[] args) {
		ArrayList<Employee59> al=new ArrayList<Employee59>();
		al.add(new Employee59(1,21000,"Shubham"));
		al.add(new Employee59(2,23000,"Trupti"));
		al.add(new Employee59(3,25000,"Ajay"));
		al.add(new Employee59(4,22000,"Kiran"));

		//Sorting by salary
		Collections.sort(al);
		for(Employee59 ep:al)
			System.out.println(ep.empno+"  "+ep.salary+"   "+ep.name);
	}
	}
