package com.Employee;

import Wednesday.Student;

public class Employee59 implements Comparable<Employee59>{
	int empno,salary;
	String name;
	public Employee59(int empno, int salary, String name) {
		super();
		this.empno = empno;
		this.salary = salary;
		this.name = name;
	}
	public int compareTo(Employee59 obj) 
	{
		if(salary==obj.salary)
		return 0;
		else if(salary>obj.salary)
			return 1;
		else
			return -1;
	}
	
}
