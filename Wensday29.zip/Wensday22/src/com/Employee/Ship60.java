package com.Employee;

import java.util.ArrayList;

import Wednesday.Employee58;

public class Ship60 {
	ArrayList<Adult> a1=new ArrayList<Adult>();
	a1.add(new Adult);

}
