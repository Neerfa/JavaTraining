package com.Employee;

public class CrewMemebers implements Comparable<Ship60>  {
	int no,cmage;
	String name;
	int ticket;
	public CrewMemebers(int no, int cmage, String name, int ticket) {
		super();
		this.no = no;
		this.cmage = cmage;
		this.name = name;
		this.ticket = ticket;
	}
	@Override
	public int compareTo(Ship60 obj) {
		{
			if (cmage == obj.cmage)
				return 0;
			else if (cmage > obj.cmage)
				return 1;
			else
				return -1;
		}
	}
	

}
