package Wednesday;

import java.util.Comparator;

public class EmployeeAge implements Comparator {

	@Override
	public int compare(Object arg0, Object arg1) {
		Employee58 a1=(Employee58)arg0;
		Employee58 a2=(Employee58)arg0;
		if(a1.empage==a2.empage)		
		return 0;
		else if(a1.empage > a2.empage)
			return 1;
		else
			return -1;

		
	}

}
