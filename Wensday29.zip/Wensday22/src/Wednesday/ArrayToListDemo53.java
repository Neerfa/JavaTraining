package Wednesday;
import java.util.*;
public class ArrayToListDemo53
{
public static void main(String[] args)
{
	//array
	String arr[]= {"Shubham","Geetanjali","Trupti","Ajay"};
	System.out.println("the array is :"+Arrays.toString(arr));
//Convert array to List
	ArrayList<String> list=new ArrayList<String>();
	for(String str:arr)
	{
		list.add(str);
	}
	System.out.println("The list is :"+list);
}
}