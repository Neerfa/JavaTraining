package Wednesday;
import java.util.*;
public class EmployeeMain 
{
public static void main(String[] args)
{
ArrayList<Employee58> al=new ArrayList<Employee58>();
al.add(new Employee58(101,21,"Shubham"));
al.add(new Employee58(102,23,"Trupti"));
al.add(new Employee58(103,22,"Ajay"));
al.add(new Employee58(104,24,"Kiran"));

//Sorting by age
Collections.sort(al,new EmployeeAge());
Iterator<Employee58> itr=al.iterator();
while(itr.hasNext())
{
	Employee58 emp=itr.next();
	System.out.println(emp.empage+"  "+emp.empno+"  "+emp.empname);
}
System.out.println("***************************************************");
//Sorting by name
Collections.sort(al,new EmployeeName());
Iterator<Employee58> itr1=al.iterator();
while(itr1.hasNext())
{
	Employee58 emp=itr1.next();
	System.out.println(emp.empage+"  "+emp.empno+"  "+emp.empname);
}
}
}