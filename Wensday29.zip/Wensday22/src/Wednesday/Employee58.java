package Wednesday;
public class Employee58 {
int empage,empno;
String empname;
public Employee58(int empage, int empno, String empname) {
	super();
	this.empage = empage;
	this.empno = empno;
	this.empname = empname;
}

		
}
