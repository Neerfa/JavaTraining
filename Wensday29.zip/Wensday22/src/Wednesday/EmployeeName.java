package Wednesday;

import java.util.Comparator;

public class EmployeeName implements Comparator 
{
	@Override
	public int compare(Object o1, Object o2)
	{
Employee58 ob1=(Employee58) o1; //we are creating out own object and assigning it to the compare() Object o1 and o2
Employee58 ob2=(Employee58) o2;
return 	ob1.empname.compareTo(ob2.empname);
}

}
