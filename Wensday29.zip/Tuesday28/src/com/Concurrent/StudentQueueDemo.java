package com.Concurrent;

import java.util.concurrent.ConcurrentLinkedQueue;

public class StudentQueueDemo {
	int rollno;
	String name,college;
	

	public StudentQueueDemo(int rollno, String name, String college) {
		super();
		this.rollno = rollno;
		this.name = name;
		this.college = college;
	}


	@Override
	public String toString() {
		return "StudentQueueDemo [rollno=" + rollno + ", name=" + name + ", college=" + college + "]";
	}


	public static void main(String[] args) {
		StudentQueueDemo sqd=new StudentQueueDemo(101,"Afreen","BCN clj");
		StudentQueueDemo sqd1=new StudentQueueDemo(102,"Amruta","belgam clj");
		StudentQueueDemo sqd2=new StudentQueueDemo(103,"Abhi","udpi clj");
		StudentQueueDemo sqd3=new StudentQueueDemo(104,"subham","banglor clj");
		ConcurrentLinkedQueue<StudentQueueDemo> clq=new ConcurrentLinkedQueue<StudentQueueDemo>(); 
		clq.add(sqd);
		clq.add(sqd1);
		clq.add(sqd2);
		clq.add(sqd3);
		for(StudentQueueDemo sq:clq)
		{
			System.out.println(sq);
		}


		

	}

}
