package com.Concurrent;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedQueue;


public class StudentQueue {
	int roolno;
	String name,degree;
	

	public StudentQueue(int roolno, String name,String degree) {
		super();
		this.roolno = roolno;
		this.name = name;
		this.degree=degree;
	}


	

	@Override
	public String toString() {
		return "StudentQueue [roolno=" + roolno + ", name=" + name + ", degree=" + degree + "]";
	}




	public static void main(String[] args) {
		StudentQueue sq=new StudentQueue(1,"abhi","BE");
		StudentQueue sq1=new StudentQueue(1,"abhi","BTECH");
		StudentQueue sq2=new StudentQueue(1,"abhi","BE");

		ConcurrentLinkedQueue<StudentQueue> clq=new ConcurrentLinkedQueue<StudentQueue>();
		clq.add(sq);
		clq.add(sq1);
		clq.add(sq2);
		System.out.println(clq);
		List l=new ArrayList();
		l.add(sq);
		//l.add(sq1);
		l.add(sq2);
		clq.retainAll(l);//all the elements in the queue will are present in the list will be display
		System.out.println(clq);

		

	}

}
