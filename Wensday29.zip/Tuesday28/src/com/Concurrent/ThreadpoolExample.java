package com.Concurrent;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class Tasks implements Runnable{
	String taskname;
	

	public Tasks(String taskname) {
		super();
		this.taskname = taskname;
	}


	@Override
	public void run() {
		try {
			for(int j=0;j<5;j++)
			{
				if(j==0)
				{
					Date dt=new Date();
					SimpleDateFormat sdf=new SimpleDateFormat("hh:mm:ss"); 
					System.out.println("the start time of"+taskname+" "+sdf.format(dt));
				}
				else
				{
					Date dt=new Date();
					SimpleDateFormat sdf=new SimpleDateFormat("hh:mm:ss"); 
					System.out.println("the execution time of"+taskname+" "+sdf.format(dt));
				}
			Thread.sleep(1000);
			}
			System.out.println(taskname+"is completed");
		}
		catch(Exception e) {
		e.printStackTrace();
	}
}
}

public class ThreadpoolExample {

	public static void main(String[] args) {
		Tasks rb1=new Tasks("task1");
		Tasks rb2=new Tasks("task2");
		Tasks rb3=new Tasks("task3");
		Tasks rb4=new Tasks("task4");
		Tasks rb5=new Tasks("task5");
		ExecutorService pl=Executors.newFixedThreadPool(5);
		pl.execute(rb1);
		pl.execute(rb2);
		pl.execute(rb3);
		pl.execute(rb4);
		pl.execute(rb5);
		pl.shutdown();

		// TODO Auto-generated method stub

	}

}
