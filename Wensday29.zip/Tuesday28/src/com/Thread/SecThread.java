package com.Thread;

public class SecThread implements Runnable {
	Object obj1;
	Object obj2;
	

	public SecThread(Object obj1, Object obj2) {
		super();
		this.obj1 = obj1;
		this.obj2 = obj2;
	}


	@Override
	public void run() {
		String name=Thread.currentThread().getName();
		System.out.println(name+"putting lock on obj1");
		synchronized(obj1)
		{
			System.out.println(name+"putting lock on obj1");
			work();
			System.out.println(name+"putting lock on obj2");
			synchronized(obj2)
			{
			System.out.println(name+"putting lock on obj1");
			  work();
			}
			System.out.println(name+"lock released on ojj1");	

		}
		System.out.println(name+"lock released on obj2");	

		System.out.println("finish execution");	

	}
	void work()
	{
		try {
			Thread.sleep(3000);
		}
		catch(InterruptedException e) {
			e.printStackTrace();
		}
	}
	

}
