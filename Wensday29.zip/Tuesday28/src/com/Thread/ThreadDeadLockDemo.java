package com.Thread;

public class ThreadDeadLockDemo {

	public static void main(String[] args) {
		Object obj1=new Object();
		Object obj2=new Object();
		Object obj3=new Object();
		Object obj4=new Object();
		Thread t1=new Thread(new SecThread(obj1,obj2),"t1");

	}

}
