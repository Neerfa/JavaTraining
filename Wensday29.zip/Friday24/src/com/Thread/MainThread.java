package com.Thread;

public class MainThread {

	public static void main(String[] args) {
		Thread1 t1=new Thread1();
		Thread2 t2=new Thread2();
		Thread3 t3=new Thread3();
		System.out.println(t2.isAlive());

		t1.start();
		t2.start();
		System.out.println(t2.isAlive());

		t3.start();
		System.out.println(t1.getName());
		System.out.println(t2.getName());



	}

}
