package com.ThreadPractice;

public class Thread6 extends Thread {
	static int ticket=2;
	synchronized public void run() {
	if(ticket!=0) {

	System.out.println(Thread.currentThread().getName()+" "+"gets the ticket");
	ticket--;

	try {
	sleep(2000);
	} catch (InterruptedException e) {
	// TODO Auto-generated catch block
	e.printStackTrace();
	}
	}
	else {
	System.out.println("tickets sold"+" "+"No ticket available for"+" "+Thread.currentThread().getName());
	}
	}



	public static void main(String[] args) {
		Thread6 ob = new Thread6();
		Thread obj1 = new Thread(ob, "Abhilasha");
		Thread obj2 = new Thread(ob, "Amruta");
		Thread obj3 = new Thread(ob, "Afreen");
		obj1.start();
		obj2.start();
		obj3.start();
	}

	}


