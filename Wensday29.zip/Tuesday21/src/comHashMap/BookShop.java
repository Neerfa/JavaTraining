package comHashMap;

public class BookShop {
	String bookid;
	String booktitle;
	String bookprice;
	public BookShop(String bookid, String booktitle, String bookprice) {
		super();
		this.bookid = bookid;
		this.booktitle = booktitle;
		this.bookprice = bookprice;
	}
	@Override
	public String toString() {
		return "BookShop [bookid=" + bookid + ", booktitle=" + booktitle + ", bookprice=" + bookprice + "]";
	}
	
	

}
