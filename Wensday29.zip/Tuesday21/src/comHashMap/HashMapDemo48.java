package comHashMap;
import java.util.*;
public class HashMapDemo48
{
public static void main(String[] args)
{
HashMap<Integer, String> hm=new HashMap<Integer, String>();
hm.put(1, "Gitanjali");
hm.put(2, "Subham");
hm.put(3, "sandip");
hm.put(4, "sunil");
hm.put(5, "sunil");
hm.put(4, "ajay");
Scanner ob=new Scanner(System.in);
System.out.println("enter rollno and name");
int rollno=ob.nextInt();
String name=ob.next();
hm.put(rollno, name);
System.out.println(hm);
}
}