package comHashMap;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Scanner;
import java.util.Set;

public class HashMapBook {

	public static void main(String[] args) {
		HashMap<String,BookShop> hm=new HashMap<String,BookShop>();
		BookShop b1=new BookShop("1","java","123");
		BookShop b2=new BookShop("2","python","153");
		BookShop b3=new BookShop("3","CN","233");
		hm.put("1",b1);
		hm.put("2",b2);
		hm.put("3", b3);
		Set set=hm.entrySet();
		Iterator itr=set.iterator();
		while(itr.hasNext())
		{
			Map.Entry en=(Map.Entry<String, String>)itr.next();
			System.out.println(en.getKey()+ "  "+en.getValue());
		}
		Scanner ob=new Scanner(System.in);
		
		System.out.println("****************************");

		System.out.println("Enter the bookid you want to search");
		String bookno=ob.nextLine();
		for(Map.Entry<String, BookShop> m: hm.entrySet())
			if(m.getKey().equals(bookno))
			System.out.println(m.getKey()+ " "+m.getValue());
		System.out.println("****************************");
		for(Map.Entry<String, BookShop> m: hm.entrySet())
			System.out.println(m.getKey()+ "    "+m.getValue());
		System.out.println("enter the bookid u want to sold");
		hm.remove(ob.nextLine());
		for(Map.Entry<String, BookShop> m: hm.entrySet())
			System.out.println(m.getKey()+ "    "+m.getValue());
		
		System.out.println("****************************");
		System.out.println("enter the bookid,bookname ans bookprice u want to increase the price");
		String bookid=ob.nextLine();
		String booktitle=ob.nextLine();
		String bookprice=ob.nextLine();
		BookShop b=new BookShop(bookid,booktitle,bookprice);
		hm.replace(bookid, b);
		System.out.println("the total book available is");

		for(Map.Entry<String, BookShop> m: hm.entrySet())
		System.out.println(m.getKey()+ " "+m.getValue());

	}

}
