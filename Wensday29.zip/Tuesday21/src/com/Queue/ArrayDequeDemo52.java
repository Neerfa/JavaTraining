package com.Queue;

import java.util.ArrayDeque;

public class ArrayDequeDemo52 {
public static void main(String[] args) {
	ArrayDeque<String> obj=new ArrayDeque();
	obj.add("sunil");
	obj.add("Subham");
	obj.add("Sandip");
	obj.add("Geetanjali");
	obj.add("Ajay");
	obj.addFirst("Kiran");
	obj.addLast("trupti");
	System.out.println(obj.getFirst());
	System.out.println(obj.getLast());
	System.out.println("****************************************");
	for(String abc : obj)
		System.out.println(abc);
}
}