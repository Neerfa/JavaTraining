package com.Queue;

import java.util.Iterator;
import java.util.PriorityQueue;

public class PriorityQueueDemo51 
{
public static void main(String[] args) 
{
PriorityQueue<String> queue=new PriorityQueue<String>();
queue.add("Subham");
queue.add("Sandip");
queue.add("Geetanjali");
queue.add("Ajay");//first-in-first-out
System.out.println(queue.element());//this will display the head element
System.out.println(queue.peek());//this will display the head element
System.out.println(queue.remove());//this removes the head element
System.out.println(queue.poll());//remove the head element
System.out.println("************************************************");
Iterator itr=queue.iterator();
while(itr.hasNext())
{
	System.out.println(itr.next());
}
queue.add("sunil");
queue.add("trupti");
System.out.println("************************************************");
Iterator itr1=queue.iterator();
while(itr1.hasNext())
{
	System.out.println(itr1.next());
}
System.out.println("the head is "+queue.element());//this will display the head element
}}