package com.Jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class StudentPreparedstmt {
	public static void main(String[] args)throws Exception
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		//to get connection from DriverManager
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/marlabsstud","root","Root@123");
	Scanner ob=new Scanner(System.in);
	System.out.println("enter empno,name,address");
	int sid=ob.nextInt();
	String sname=ob.next();
	String saddress=ob.next();
	PreparedStatement st=con.prepareStatement("insert into studentm_tbl values(?,?,?)");
	st.setInt(1,sid);//1 represent the first ?
	st.setString(2,sname);//2 represent the second ?
	st.setString(3,saddress);//3 represenr the third ?
	st.execute();
	System.out.println("row inserted");

}
}
