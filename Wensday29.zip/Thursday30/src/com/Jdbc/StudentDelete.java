package com.Jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class StudentDelete {
	public static void main(String[] args)throws Exception
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			//to get connection from DriverManager
			Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/marlabsstud","root","Root@123");
			Scanner ob=new Scanner(System.in);
			System.out.println("enter sid u want delete");
			int empno=ob.nextInt();
			PreparedStatement st=con.prepareStatement("delete from studentm_tbl where sid=?");
			st.setInt(1,empno);
			st.execute();
			System.out.println("row deleted");
	}
	}