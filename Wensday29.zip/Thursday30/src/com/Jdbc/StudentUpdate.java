package com.Jdbc;
import java.sql.*;
public class StudentUpdate {
	public static void main(String[] args)throws Exception
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		//to get connection from DriverManager
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/marlabsstud","root","Root@123");
			Statement st=con.createStatement();
			st.execute("update studentm_tbl set saddress='Kolkotta' where sid=101");
			System.out.println("Row updated");		
	}
	}
