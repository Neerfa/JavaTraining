package com.Jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class StudentSelect {
	public static void main(String[] args)throws Exception
	{
		Class.forName("com.mysql.cj.jdbc.Driver");
		//to get connection from DriverManager
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/marlabsstud","root","Root@123");
		Statement st=con.createStatement();
	ResultSet rs=st.executeQuery("select * from studentm_tbl");
	while(rs.next())
	{
	System.out.println(rs.getInt(1)+"   "+rs.getString(2)+"  "+rs.getString(3));	
	}

}
}
