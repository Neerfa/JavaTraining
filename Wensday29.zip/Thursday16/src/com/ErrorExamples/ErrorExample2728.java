package com.ErrorExamples;
import java.util.*;
public class ErrorExample2728 
{
public static void main(String[] args) 
{
	try//try with multiple catch
	{
Scanner ob=new Scanner(System.in);
System.out.println("Enter 2 nos");
int a=ob.nextInt();
int b=ob.nextInt();
int c=a/b;
System.out.println("The result is "+c);
	}
	catch(ArithmeticException ae)
	{
		System.out.println("the error is "+ae);
	}
	catch(InputMismatchException ae)
	{
		System.out.println("the errorr is "+ae);
	}
	catch(Exception ae)
	{
		System.out.println("the errorrr is "+ae);
	}
System.out.println("The end of the program");
}
}