package com.ErrorExamples;

public class ThrowsKeyWord30 {
	public static void main(String[] args) throws Exception
	{
		for(int i=1;i<=10;i++)
		{
			System.out.println(i);
			Thread.sleep(5000);//interrupt the flow of control
		}
	}
}
	
