package com.ErrorExamples;

import java.util.Scanner;

public class throwsException31 {
	public static void main(String[] args) throws Exception
	{
		Scanner ob=new Scanner(System.in);
		System.out.println("enter your age to cast your vote");
		int age=ob.nextInt();
		if(age>=18)
			System.out.println("your are eligible to cash your vote");
		else
			throw new Exception("The age should be greater than or equal to 18 to caste your vote");
	}
	}
