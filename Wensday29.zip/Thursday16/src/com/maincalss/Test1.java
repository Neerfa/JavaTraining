package com.maincalss;
public class Test1
{
public static void main(String h[]) 
{
String a=h[0];
String b=h[1];
String c=h[2];
int x=Integer.parseInt(a);
int y=Integer.parseInt(b);
int z=Integer.parseInt(c);
int sum=x+y+z;
System.out.println("the sum is "+sum);

String a1=h[0];
String b1=h[1];
String c1=h[2];
float x1=Float.parseFloat(a);
float y1=Float.parseFloat(b);
float z1=Float.parseFloat(c);
float sum1=x1+y1+z1;
System.out.println("the sum is "+sum1);
}
}