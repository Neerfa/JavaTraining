package com.Static;
public final class FinalDemo23 
{
final int a=10;
final void display()
{
	System.out.println("this is final display");
}
public static void main(String[] args) {
	FinalDemo23 ob=new FinalDemo23();
	ob.display();
	System.out.println("the value of a is"+ob.a);
}
}