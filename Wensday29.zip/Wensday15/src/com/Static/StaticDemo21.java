package com.Static;
public class StaticDemo21 
{
static int rollno=10;
static String name="trupti";
static String address="orissa";
static void display()
{
	System.out.println(rollno+ " "+name+"  "+address);
}
static
{
	System.out.println("This is a static block");
}
public static void main(String[] args)
{
System.out.println("rollno is "+rollno);	
System.out.println("the name is "+StaticDemo21.name);
System.out.println("the address is"+StaticDemo21.address);
display();
StaticDemo21.display();
}}