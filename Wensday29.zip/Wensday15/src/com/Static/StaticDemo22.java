package com.Static;
public class StaticDemo22 
{
static int rollno=10;
static String name="trupti";
 static String address="orissa";
 static int i;
static void display()//we cannot access a non-static variable inside a static method.
{
	System.out.println(rollno+ " "+name+"  "+address);
}
static void counter()
{
	i++;
	System.out.println(i);
}
static 
{
	System.out.println("This is a static block");
}
public static void main(String[] args)//we cannot access a non-static variable inside a static method.
{
System.out.println("rollno is "+rollno);	
System.out.println("the name is "+StaticDemo22.name);
System.out.println("the address is"+StaticDemo22.address);
display();
StaticDemo22.display();
counter();
counter();
counter();
counter();
}}