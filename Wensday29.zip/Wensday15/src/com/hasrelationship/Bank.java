package com.hasrelationship;

public class Bank {
	int accno,balance;
	String branch;
	Customer customer;
	
	public Bank(int accno, int balance, String branch, Customer customer) {
		super();
		this.accno = accno;
		this.balance = balance;
		this.branch = branch;
		this.customer = customer;
	}

	void display()
	{
		System.out.println("accno:"+accno+"balance:"+balance+"branch:"+branch+"customer:"+customer);
	}
	}


