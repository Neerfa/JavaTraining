package com.hasrelationship;

public class Customer {
 int cid;
 String name,address;
public Customer(int cid, String name, String address) {
	super();
	this.cid = cid;
	this.name = name;
	this.address = address;
}
@Override
public String toString() {
	return "Customer [cid=" + cid + ", name=" + name + ", address=" + address + "]";
}
public static void main(String[] args) 
{
	Customer customer=new Customer(1,"Afreen","Banglore");
	Bank bnk=new Bank(1,23000,"Lakshmeshwar",customer);
	bnk.display();
}
}
