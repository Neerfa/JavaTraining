package com.program24;

public interface dept{	
	int deptno=1;
	String name="Associate",loc="north bangalore";
		public void display2();
		
	}



