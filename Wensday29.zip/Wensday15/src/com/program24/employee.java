package com.program24;

public interface employee extends dept {
	int empno=101;
	String emp_name="amruta",address="Bangalore";
	public void display1();
}