package com.overriding;
class Parent
{
void display()
{
	System.out.println("This is a parent class");
}
}
public class MethodOverriding16 extends Parent
{
	void display()
	{
		System.out.println("this is new display method");
	}
	public static void main(String[] args) 
	{
		MethodOverriding16 ob=new MethodOverriding16();
		ob.display();
	}
}

