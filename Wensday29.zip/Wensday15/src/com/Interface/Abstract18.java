package com.Interface;
abstract class Abstract18
{
Abstract18()
{
	System.out.println("this is a constractor");
}
Abstract18(int a,int b)
{
	System.out.println("the sum of super constrctor is "+(a+b));
}
abstract void display();
int sum(int a,int b)
{
	return a+b;
}
}
class AbstractDemo1 extends Abstract18
{
	AbstractDemo1()
	{
		super();
	}
	AbstractDemo1(int a,int b)
	{
		super(a,b);
	}
	@Override
	void display() 
	{
		System.out.println("This is display");
		}
	public static void main(String[] args) {
		AbstractDemo1 ob1=new AbstractDemo1();
		AbstractDemo1 ob=new AbstractDemo1(7,8);
		
		System.out.println("the sum is "+ob.sum(6, 3));
		ob.display();
	}
}