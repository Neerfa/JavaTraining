package com.Interface;
abstract class Abstract117
{

public Abstract117()
{
	System.out.println("this is constructor");
}

abstract void display();
int sum(int a,int b)
{
	return a+b;
}
}
class AbstractDemo extends Abstract117
{
	@Override
	void display() 
	{
		System.out.println("This is display");
		}
	public static void main(String[] args) {
		AbstractDemo ob=new AbstractDemo();
		System.out.println("the sum is "+ob.sum(6, 3));
		ob.display();
	}
}