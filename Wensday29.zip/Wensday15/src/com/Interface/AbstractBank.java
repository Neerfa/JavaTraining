package com.Interface;

abstract class AbstractBank {
	abstract void register();
	abstract void applyforloan();
	abstract void criditCard();
	abstract void debitcard();
}
	
class Customer extends AbstractBank
{

	@Override
	void register() {
		System.out.println("ur account is created");
		
	}

	@Override
	void applyforloan() {
		System.out.println("ur loan is sunctioned");
		
	}

	@Override
	void criditCard() {
		System.out.println("ur criditcard is redy");
		
	}

	@Override
	void debitcard() {
		System.out.println("ur debitcard is reay");
		
	}
	public static void main(String[] args) {
		Customer c=new Customer();
		c.register();
		c.applyforloan();
		c.criditCard();
		c.debitcard();
		
	}
}
