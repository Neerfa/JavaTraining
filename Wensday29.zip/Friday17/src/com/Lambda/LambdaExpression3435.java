package com.Lambda;

interface Example1{
 public void display();
}

interface Example2{
	 public String display2();
	}

interface Example3{
	 public String display3(String address);
	}

interface Example4{
	public int display4(int a,int b);
}



public class LambdaExpression3435 {

	public static void main(String[] args) {
		int length=10;
		int breadth=20;
		Example1 obj=()->{
			System.out.println("the length is"+length);
			System.out.println("the length is"+breadth);
			System.out.println("the length is"+length*breadth);	
		};
		obj.display();
		
		Example2 obj2=()->
		{
			return "Lambda Expression";
		};
		System.out.println(obj2.display2());
		
		Example3 obj3=(address)->
		{
			return "My address is"+address;
		};
		obj3.display3("Lakshmeshwar");
		
		
		Example4 obj4=(a,b)->
		{
			return a+b;
		};
		System.out.println(obj4.display4(4,5));

		// TODO Auto-generated method stub

	}

}
