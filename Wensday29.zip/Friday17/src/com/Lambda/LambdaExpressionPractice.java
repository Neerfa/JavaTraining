package com.Lambda;

import java.util.Scanner;

interface bank1{
	public String deposite(int n1);
}

interface bank2{
	public String withdraw(int n2);
}

interface bank3{
	public int balance();
}

public class LambdaExpressionPractice {
	private static int balance=0;
	private static int amount1,amount2;
	public static void main(String[] args) {
		transaction();
	}
		
		private static void transaction(){
		Scanner sc=new Scanner(System.in);
			System.out.println("please enter ur choice:\n"
				+ "1 for deposite\n"
				+  "2 for withdrawal\n"
				+  "3 for balance");
		
		int choice=sc.nextInt();
		switch(choice)
		{
		case(1):
			    System.out.println("please enter amount1");
		        amount1=sc.nextInt();
		        balance = amount1+ balance;
		        bank1 b1=(n1)->
				{
					return "amount credited to ur account is"+n1;
				};
				
				System.out.println(b1.deposite(amount1));
				transaction();
		         break;
		
		case(2):
			    System.out.println("please enter amount to withdraw");
                amount2=sc.nextInt();
                balance =balance-amount2;
                bank2 b2=(n2)->
		        {
			      return "amount debited to ur account is"+n2;
		        };
		
		        System.out.println(b2.withdraw(amount2));
				transaction();
                break;
                
		case(3):
			     bank3 b3=()->
		        {
		          System.out.println(balance);
			      return balance;
		        };
		        b3.balance();
				transaction();
		        break;
		        
		}
		
	}

}
