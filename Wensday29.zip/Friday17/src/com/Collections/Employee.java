package com.Collections;

public class Employee {
String empname;
int empno,salary;
public Employee(String empname, int empno, int salary) {
	super();
	this.empname = empname;
	this.empno = empno;
	this.salary = salary;
}
@Override
public String toString() {
	return "Employee [empname=" + empname + ", empno=" + empno + ", salary=" + salary + "]";
}


}
