package com.Collections;

import java.util.LinkedHashSet;

public class StudentstaticDemo 
{
public static void main(String[] args)
{
	Student40 ob=new Student40(101,"sandip","bangalore");
	Student40 ob1=new Student40(102,"shubam","bangalore");
	Student40 ob2=new Student40(103,"trupti","bangalore");
	
LinkedHashSet ts=new LinkedHashSet();
ts.add(ob);
ts.add(ob1);
ts.add(ob2);
System.out.println(ts);
}
}