package com.Collections;

import java.util.LinkedHashSet;

public class EmpStaticDemo {

	public static void main(String[] args) {
		Employee emp=new Employee("Afreen",1,230);
		Employee emp1=new Employee("Abi",2,223);
		Employee emp2=new Employee("Amruta",3,243);
		LinkedHashSet lhs=new LinkedHashSet();
		lhs.add(emp);
		lhs.add(emp1);
		lhs.add(emp2);
		System.out.println(lhs);
		// TODO Auto-generated method stub

	}

}
