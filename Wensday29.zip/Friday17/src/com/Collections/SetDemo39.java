package com.Collections;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class SetDemo39 {
	public static void main(String[] args)
	{
	TreeSet<Integer> ts=new TreeSet<Integer>();
	ts.add(70);
	ts.add(20);
	ts.add(30);
	ts.add(10);
	ts.add(50);
	ts.add(50);
	ts.add(60);
	System.out.println(ts);
	
	HashSet<Integer> hs=new HashSet<Integer>();
	hs.add(70);
	hs.add(20);
	hs.add(30);
	hs.add(10);
	hs.add(50);
	hs.add(50);
	hs.add(60);
	System.out.println(hs);
	
	LinkedHashSet<Integer> lhs=new LinkedHashSet<Integer>();
	lhs.add(70);
	lhs.add(20);
	lhs.add(30);
	lhs.add(10);
	lhs.add(50);
	lhs.add(50);
	lhs.add(60);
	System.out.println(lhs);
	}
	}

