package com.Shoping;

public class ShopingDetails {
	String pname;
	int price;
	public ShopingDetails(String pname, int price) {
		super();
		this.pname = pname;
		this.price = price;
	}
	@Override
	public String toString() {
		return "ShopingDetails [pname=" + pname + ", price=" + price + "]";
	}
	


}
