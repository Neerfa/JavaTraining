package com.Shoping;

import java.util.EnumMap;
import java.util.Map;

public class SopingEnumMap {
	enum shoping{shop,online};

	public static void main(String[] args) {
		EnumMap<shoping, ShopingDetails> em=new EnumMap<shoping, ShopingDetails>(shoping.class);
		ShopingDetails ob1=new ShopingDetails("cotton material",1000);
		ShopingDetails ob2=new ShopingDetails("Net material",2500);
		em.put(shoping.shop, ob1);
		em.put(shoping.online, ob2);
		for(Map.Entry<shoping, ShopingDetails> ab:em.entrySet())
		{
			System.out.println(ab.getKey()+"    "+ab.getValue());
		}
		

	}

}
