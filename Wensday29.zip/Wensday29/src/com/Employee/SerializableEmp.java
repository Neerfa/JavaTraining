package com.Employee;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class SerializableEmp {

	public static void main(String[] args) throws IOException {
		Employee e=new Employee();
		e.empno=101;
		e.empname="Afreen";
		e.designation="Devloper";
		e.salary=2322;
		FileOutputStream fos=new FileOutputStream("object1.txt");
		ObjectOutputStream os=new ObjectOutputStream(fos);
		os.writeObject(e);
		fos.close();os.close();
		System.out.println("Object written into the file.......");
		}
	}
