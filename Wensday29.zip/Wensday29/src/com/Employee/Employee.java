package com.Employee;

import java.io.Serializable;

public class Employee implements Serializable  {
int empno,salary;
String empname,designation;
}
