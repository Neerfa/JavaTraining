package com.Employee;

import java.io.FileInputStream;
import java.io.ObjectInputStream;

public class DeSerializableEmp {

	public static void main(String[] args) throws Exception
	{
		Employee e1=new Employee();
		FileInputStream fos=new FileInputStream("object1.txt");
		ObjectInputStream os=new ObjectInputStream(fos);
		e1=(Employee) os.readObject();
		fos.close();os.close();
	System.out.println("the empno is :"+e1.empno);
	System.out.println("the empname is :"+e1.empname);
	System.out.println("the salary is :"+e1.salary);
	System.out.println("the sdesignation is :"+e1.designation);

	}}

