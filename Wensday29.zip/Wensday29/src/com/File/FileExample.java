package com.File;
import java.util.*;
import java.io.*;

public class FileExample {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enetr the file name");
		String s = sc.next();
		File f=new File(s);
		System.out.println("the file name is"+f.getName());
		System.out.println("the file path is"+f.getPath());
		System.out.println("the file AbsolutePath is"+f.getAbsolutePath());
		System.out.println("the file is existing "+f.exists());
		System.out.println("the file is in write mode "+f.canWrite());
		System.out.println("the file is in read mode "+f.canRead());
		System.out.println("the file is in execute mode "+f.canExecute());
		System.out.println("the file length is "+f.length());
		System.out.println("the is a file "+f.isFile());
		System.out.println("the is a directory "+f.isDirectory());







	}

}
