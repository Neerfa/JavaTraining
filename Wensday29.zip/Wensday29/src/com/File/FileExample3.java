package com.File;
import java.io.*;

public class FileExample3 {

	public static void main(String[] args) throws Exception {
		FileInputStream fis=new FileInputStream("student.txt");
		FileOutputStream fos=new FileOutputStream("student1.txt");
		int data;
		while((data=fis.read())!='\n')
		{
			fos.write(data);
		}
		fis.close();
		fos.close();
		System.out.println("file copied...................");

	}

}
