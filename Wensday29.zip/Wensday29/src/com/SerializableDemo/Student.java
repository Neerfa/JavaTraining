package com.SerializableDemo;

import java.io.Serializable;

public class Student implements Serializable 
{
int rollno;
String name,address;
}
