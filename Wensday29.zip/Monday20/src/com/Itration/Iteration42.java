package com.Itration;

import java.util.Iterator;
import java.util.TreeSet;

public class Iteration42 {

	public static void main(String[] args) {
		TreeSet<Integer> ts=new TreeSet<Integer>();
		System.out.println(ts.isEmpty());
		System.out.println(ts.size());
		ts.add(70);
		ts.add(20);
		ts.add(30);
		ts.add(10);
		ts.add(50);
		ts.add(50);
		ts.add(60);
		//for each loop
		for(Object obj:ts)
			System.out.println(obj);
		
		System.out.println("************************");
		//Iterator
		Iterator itr=ts.iterator();
		while(itr.hasNext())
		{
			System.out.println(itr.next());
		}
		System.out.println("************************");


	}

}
