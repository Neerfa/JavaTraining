package com.Boxing;

public class AutoBoxing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		Integer b=new Integer(a);
		System.out.println(b);

	}

}
