package com.Boxing;

public class Unboxing {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Integer a=new Integer(10);
		int b=a;
		System.out.println(b);

	}

}
