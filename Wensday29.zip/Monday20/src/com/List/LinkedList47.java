package com.List;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;

public class LinkedList47 {

	public static void main(String[] args) {
		LinkedList<Integer> ll=new LinkedList<Integer>();

		ll.add(10);
		ll.add(20);
		ll.add(30);
		ll.add(40);
		ll.add(50);
		Collections.sort(ll);
		ll.forEach((x)->System.out.println(x));
		System.out.println("the largest no is "+Collections.max(ll));
		System.out.println("the smallest no is "+Collections.min(ll));
		
		LinkedList<String> ls1=new LinkedList<String>();
		ls1.add("Trupti");
		ls1.add("Shubham");
		ls1.add("Madhu");
		ls1.add("Geetanjali");
		ls1.add("Sunil");
		ls1.add("Deepak");
		Collections.sort(ls1);
		ls1.forEach((x)->System.out.println(x));
		
		ArrayList<Integer> al=new ArrayList<Integer>();
		al.add(10);
		al.add(40);
		al.add(30);
		al.add(20);
		al.add(50);
		Collections.sort(al);
		al.forEach((x)->System.out.println(x));
		System.out.println("the largest no is "+Collections.max(al));
		System.out.println("the smallest no is "+Collections.min(al));
		
		ArrayList<Integer> al2=new ArrayList<Integer>();
		al2.add(10);
		al2.add(40);
		al2.add(30);
		al2.add(20);
		al2.add(50);
		Collections.sort(al2,Collections.reverseOrder());
		al2.forEach((x)->System.out.println(x));
		
		ArrayList<Integer> al3=new ArrayList<Integer>();
		al3.add(Integer.valueOf(10));//it will convert Object to primative datatype
		al3.add(Integer.valueOf(40));
		al3.add(30);//it internally convert object to primative datatype
		al3.add(20);
		al3.add(50);
		Collections.sort(al3,Collections.reverseOrder());
		al3.forEach((x)->System.out.println(x));
		
	}

}
