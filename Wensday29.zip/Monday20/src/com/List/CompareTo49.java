package com.List;

import java.util.ArrayList;
import java.util.Collections;

public class CompareTo49 {
	
		public static void main(String[] args) 
		{
		ArrayList<MarlabsEmp49> al=new ArrayList<MarlabsEmp49>();
		al.add(new MarlabsEmp49(104,"Geetanjali"));
		al.add(new MarlabsEmp49(103,"Shubam"));
		al.add(new MarlabsEmp49(102,"Deepak"));
		al.add(new MarlabsEmp49(101,"Trupti"));
		Collections.sort(al);
		
		for(MarlabsEmp49 ob:al)
			System.out.println(ob);
		}
}
