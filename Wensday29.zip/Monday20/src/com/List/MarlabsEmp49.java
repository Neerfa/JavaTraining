package com.List;

public class MarlabsEmp49 implements Comparable<MarlabsEmp49> {
	Integer empid;
	String name;

	MarlabsEmp49(Integer empid, String name) {
		this.empid = empid;
		this.name = name;
	}

	
	public int compareTo(MarlabsEmp49 obj) {
		return empid.compareTo(obj.empid);
	}


	@Override
	public String toString() {
		return "MarlabsEmp49 [empid=" + empid + ", name=" + name + "]";
	}


	
}


