package com.List;

import java.util.Stack;

public class ListSetDemo4344 {

	public static void main(String[] args) {
    Stack<Integer> st=new Stack<Integer>();
    st.push(10);
    st.push(20);
    st.push(30);
    st.push(40);
    st.push(50);
    for(Object obj:st)
    	System.out.println(obj);
    System.out.println(st.search(50));
    System.out.println(st.pop());//delete the data
    System.out.println(st);
    System.out.println(st.peek());//it will sow but not delete the data from list
    System.out.println(st);
    st.forEach((a)->System.out.println(a));//The wrapper class super class is Object
    System.out.println(st.search(10));//It will return the position of 10.It is last
    System.out.println(st.search(40));
    System.out.println(st.search(200));//element not found it displays -1
    System.out.println(st.clone());//creta the exact copy of original object



    
	}

}
//search start from 1
//indexOf start from 0
