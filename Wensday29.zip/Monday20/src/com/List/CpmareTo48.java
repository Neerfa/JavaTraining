package com.List;

import java.util.ArrayList;
import java.util.Collections;

public class CpmareTo48 {
	
		public static void main(String[] args) 
		{
		ArrayList<MarlabsEmp> al=new ArrayList<MarlabsEmp>();
		al.add(new MarlabsEmp("Geetanjali"));
		al.add(new MarlabsEmp("Shubam"));
		al.add(new MarlabsEmp("Deepak"));
		al.add(new MarlabsEmp("Trupti"));
		Collections.sort(al);
		for(MarlabsEmp ob:al)
			System.out.println(ob.name);
		}

}
