package com.cookie;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class addCookie
 */
@WebServlet("/AddCookie")
public class AddCookie extends HttpServlet {
	public void  doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException
	{
	resp.setContentType("Text/html");
	PrintWriter pw=resp.getWriter();
	String key=req.getParameter("t1");
	String value=req.getParameter("t2");
	Cookie c=new Cookie(key,value);
	resp.addCookie(c);
	pw.println("the kay is"+key);
	pw.println("the value is"+value);
	pw.println("cookies added successfully");


	}

}
