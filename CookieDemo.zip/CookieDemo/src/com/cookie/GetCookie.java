package com.cookie;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class GetCookie
 */
@WebServlet("/GetCookie")
public class GetCookie extends HttpServlet {
	public void  doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException
	{
	resp.setContentType("Text/html");
	PrintWriter pw=resp.getWriter();
	pw.println("<html>");
	pw.println("<h1>The cookies stored are</h1>");
	Cookie ck[]=req.getCookies();
	for(int i=0;i<ck.length;i++)
	{
		String key=ck[i].getName();
		String value=ck[i].getValue();
		pw.println("the kay is"+key);
		pw.println("the value is"+value);

	}
	pw.println("</html>");

	}
}
