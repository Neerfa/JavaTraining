package com.marlabs.training.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import com.marlabs.training.dao.DaoException;

public class DbUtil {

	public static Connection getConnection()throws DaoException,Exception
	{
		String driver,url,username,password;
		 driver="com.mysql.cj.jdbc.Driver";
		 url="jdbc:mysql://localhost:3306/marlabsstud";
		 username="root";
		 password="Root@123";
		 Class.forName(driver);
		 return DriverManager.getConnection(url,username,password);
	}
}
