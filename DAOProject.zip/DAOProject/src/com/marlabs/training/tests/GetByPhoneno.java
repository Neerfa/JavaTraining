package com.marlabs.training.tests;

import com.marlabs.training.dao.DaoException;
import com.marlabs.training.dao.PersonDao;
import com.marlabs.training.dao.impl.JdbcpersonDao;
import com.marlabs.training.entity.Person;

public class GetByPhoneno {

	public static void main(String[] args) throws DaoException {
		PersonDao dao=new JdbcpersonDao();
		String Phoneno="9036580430";
		Person p=dao.getPersonByPhoneno(Phoneno);
		if(p==null)
		{
			System.out.println("Person data not there");
		}
		else
		{
			System.out.println(p);
		}
		
	}
}
