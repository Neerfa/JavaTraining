package com.marlabs.training.tests;

import com.marlabs.training.dao.DaoException;
import com.marlabs.training.dao.PersonDao;
import com.marlabs.training.dao.impl.JdbcpersonDao;
import com.marlabs.training.entity.Person;

public class AddPerson {

	public static void main(String[] args) throws DaoException {
		Person person =new Person(101,"sandip","kumar","9988776655","sandip@gmail.com");
		PersonDao dao=new JdbcpersonDao();
		dao.addPerson(person);
		System.out.println("Person data added");
	}

}
