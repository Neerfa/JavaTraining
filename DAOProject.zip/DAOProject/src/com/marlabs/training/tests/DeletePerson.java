package com.marlabs.training.tests;

import com.marlabs.training.dao.DaoException;
import com.marlabs.training.dao.PersonDao;
import com.marlabs.training.dao.impl.JdbcpersonDao;

public class DeletePerson {

	public static void main(String[] args) throws DaoException {
		PersonDao dao=new JdbcpersonDao();
		int sid=101;
		//Person p=dao.getPerson(id);
		dao.deletePerson(sid);
		System.out.println("Person data deleted");

	}

}
