package com.marlabs.training.tests;

import java.util.List;

import com.marlabs.training.dao.DaoException;
import com.marlabs.training.dao.PersonDao;
import com.marlabs.training.dao.impl.JdbcpersonDao;
import com.marlabs.training.entity.Person;

public class GetAllPersons {

	public static void main(String[] args) throws DaoException {
		PersonDao dao=new JdbcpersonDao();
		List <Person>list=dao.getAllPersons();
		for(Person p : list)
		{
		System.out.println(p.getId()+" "+p.getFirstname()+" "+p.getLastname());
	}
	}
}
