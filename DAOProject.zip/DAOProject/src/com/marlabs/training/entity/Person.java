package com.marlabs.training.entity;

public class Person {

	private int sid;
	private String firstname;
	private String lastname;
	private String phoneno;
	private String emial;
	
	
	public Person(int id, String firstname, String lastname, String phoneno, String emial) {
		super();
		this.sid = id;
		this.firstname = firstname;
		this.lastname = lastname;
		this.phoneno = phoneno;
		this.emial = emial;
	}


	public Person() {
		super();
		// TODO Auto-generated constructor stub
	}


	public int getId() {
		return sid;
	}


	public void setId(int id) {
		this.sid = id;
	}


	public String getFirstname() {
		return firstname;
	}


	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}


	public String getLastname() {
		return lastname;
	}


	public void setLastname(String lastname) {
		this.lastname = lastname;
	}


	public String getPhoneno() {
		return phoneno;
	}


	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}


	public String getEmial() {
		return emial;
	}


	public void setEmial(String emial) {
		this.emial = emial;
	}


	@Override
	public String toString() {
		return "Person [id=" + sid + ", firstname=" + firstname + ", lastname=" + lastname + ", phoneno=" + phoneno
				+ ", emial=" + emial + "]";
	}
	
	
	

	
}
