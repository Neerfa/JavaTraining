package com.sub;

public class Subject {

	private String name;
	private String comment;
	public void setSubject(String na)
	{
	this.name=na;
	}
	public String getComment()
	{
	if(name.equals("JAVA"))
	return "jAVA is oop language";
	if(name.equals("C"))
	return "C is structured language";
	if(name.equals("PYTHON"))
	return " PYTHON is machine level language";
	else
	return "Sorry Invalied entry";
	}
	

}
