package NewYear22;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class JDBC2 {
	public static void main(String[] args)throws Exception
	{
		String driverclass="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/marlabsstud";
		String username="root";
		String password="Root@123";
		String sql="insert into Employee_tbl values(101,'shubham','7766554433',19000)";
		Class.forName(driverclass);
		Connection con=DriverManager.getConnection(url,username,password);
		Statement st=con.createStatement();
		int count=st.executeUpdate(sql);
		System.out.println("inserted row = "+count);

}
}
