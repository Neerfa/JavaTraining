package NewYear22;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class JDBC3 {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		String driverclass="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/marlabsstud";
		String username="root";
		String password="Root@123";
		String sql="insert into studentEmp_tbl values(?,?,?)";
		Class.forName(driverclass);
		Connection con=DriverManager.getConnection(url,username,password);
		PreparedStatement st=con.prepareStatement(sql);
		Scanner ob=new Scanner(System.in);
		System.out.println("enter studid,name,address");
		int sid=ob.nextInt();
		String sname=ob.next();
		String saddress=ob.next();
		st.setInt(1, sid);
		st.setString(2, sname);
		st.setString(3, saddress);
		int count=st.executeUpdate();
		System.out.println("inserted row = "+count);

	}

}
