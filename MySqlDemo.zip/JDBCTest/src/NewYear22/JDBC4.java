package NewYear22;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

public class JDBC4 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		String driverclass="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/marlabsstud";
		String username="root";
		String password="Root@123";
		String sql="DELETE from studentEmp_tbl";
		String sql1="truncate table studentEmp_tbl";
		Class.forName(driverclass);
		Connection con=DriverManager.getConnection(url,username,password);
		PreparedStatement st=null;
		System.out.println("***************************************");
		System.out.println("enter 1 for DELETE ALL STUDENT");
		System.out.println(" enetr 2 for DELETE BY SID");
		System.out.println("enter 4 for DELETE BY SADDRESS");
		System.out.println("enter 3 for DELETE BY NAME");
		System.out.println("***************************************");
		Scanner ob=new Scanner(System.in);
		System.out.println("ENETER YOUR CHOICE");
		int option =ob.nextInt();
		switch(option)
		{
		case 1:
			st=con.prepareStatement(sql1);
			System.out.println("deleted all rows" );
			break;
		case 2:
			sql+=" where studid=?";
			System.out.println(sql);
			System.out.println("enter sid");
			int studid=ob.nextInt();
			st=con.prepareStatement(sql);
			st.setInt(1,studid);
			break;
		case 3:
			sql+=" where sname=?";
			System.out.println(sql);
			System.out.println("enter sname");
			String name=ob.next();
			st=con.prepareStatement(sql);
			st.setString(1, name);
			break;
		case 4:
			sql+=" where saddress=?";
			System.out.println(sql);
			System.out.println("enter saddress");
			String saddress=ob.next();
			st=con.prepareStatement(sql);
			st.setString(1, saddress);
			break;
			default:
				System.out.println("sory wrong option you have enterd");
				break;
			
			
			
		}
		int count=st.executeUpdate();
		if(count==0)
			System.out.println("sorry no rows updated");
		else
			System.out.println("Rows deleted is :"+count);
			con.close();
	}

}
