package SpringCore1;

public class Employee {
	private int empid;
	private String name,address;
	public Employee(int empid, String nam, String address) {
		super();
		this.empid = empid;
		this.name = nam;
		this.address = address;
	}
	public Employee() {
		System.out.println("this is default constructor");
		// TODO Auto-generated constructor stub
	}
	void display() {
		System.out.println("the id is "+empid);
		System.out.println("the name is "+name);
		System.out.println("the address is "+address);
	}
	

}
