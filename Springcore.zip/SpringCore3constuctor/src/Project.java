
public class Project {
private String pid,pname,manager,location;

public Project(String pid, String pname, String manager, String location) {
	super();
	this.pid = pid;
	this.pname = pname;
	this.manager = manager;
	this.location = location;
}

@Override
public String toString() {
	return "Project [pid=" + pid + ", pname=" + pname + ", manager=" + manager + ", location=" + location + "]";
}

}
