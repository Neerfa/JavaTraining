

public class Employee
{
private int empno;
private String name,mail,phone;
private Project project;
public Employee(int empno, String name, String mail, String phone, Project project) {
	super();
	this.empno = empno;
	this.name = name;
	this.mail = mail;
	this.phone = phone;
	this.project = project;
}
@Override
public String toString() {
	return "Employee [empno=" + empno + ", name=" + name + ", mail=" + mail + ", phone=" + phone + ", project="
			+ project + "]";
}




 



}
