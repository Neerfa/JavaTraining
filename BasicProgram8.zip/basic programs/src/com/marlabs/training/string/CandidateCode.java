package com.marlabs.training.string;

import java.util.Scanner;

public class CandidateCode {
	public static void main(String args[]) throws Exception {
		Scanner sc = new Scanner(System.in);
		String s1 = sc.nextLine();
		String s2 = sc.nextLine();

		CandidateCode cc = new CandidateCode();
		cc.SubString(s1, s2);
	}

	// Write code here

	public int SubString(String p, String q) {
		String s3 = p;
		String s4 = q;
		int count = 0;
		int size = s3.length();
		int size1 = s4.length();
		for (int i = 0; i < size - 1; i++) {
			String s5 = "";
			if (i == size - 2 && i + 2 == size) {
				s5 = s3.substring(i);
			} else {

				s5 = s3.substring(i, i + 2);
			}

			if (s4.equals(s5)) {
				count = count + 1;
			}

			s5 = "";

		}

		System.out.println(count);
		return count;
	}
}

