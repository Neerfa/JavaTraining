package com.marlabs.training.string;

import java.util.Scanner;

public class NumericContain {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		if(s.matches("[a-zA-Z0-9]+"))
		{
		       System.out.println("True");
		 
		}
		else
		{
		    System.out.println("False");
		}
	}

}
