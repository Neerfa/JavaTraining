package com.marlabs.training.string;

import java.util.Scanner;

public class SuffixString {
	public static void main(String args[] ) throws Exception {

		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		String s2=sc.nextLine();
		int size1=s.length();
		int size2=s2.length();
		int n=size1-size2;
		System.out.println(n);
		String s3=s.substring(n);
		if(s3.equals(s2))
		{
		    System.out.println("True");
		}
		else
		{
		    System.out.println("False");
		}
		   }
		}

