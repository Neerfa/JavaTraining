package com.marlabs.training.string;

public class RevrseString {

	public static void main(String[] args) {
		//by using builtin function
		 String str1 = "Automation";
		 
        StringBuilder str2 = new StringBuilder();
        str2.append(str1);
        str2 = str2.reverse();     // used string builder to reverse
       System.out.println(str2);
        
		
		String str="Automation";
		char[] c=str.toCharArray();
		int size=c.length;
		String s2=" ";
		
		for(int i=size-1;i>=0;i--) {
			s2=s2+c[i];
		}
		System.out.println(s2);
	}
}


