package com.marlabs.training.leapyear;

import java.util.Scanner;

public class Leapyear {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("please enter year");
		int year=sc.nextInt();
		
		if(year%4==0||year%400==0&&year%100!=0)
			System.out.println("given year is leap year:"+year);
		else
			System.out.println("given year is not leap year:"+year);


	}

}
