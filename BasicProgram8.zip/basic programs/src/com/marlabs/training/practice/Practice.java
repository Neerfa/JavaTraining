package com.marlabs.training.practice;

import java.util.Arrays;
import java.util.Scanner;

public class Practice {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("please enter the size of array a");
		int m=sc.nextInt();
		System.out.println("please enter the size of array b");
		int n=sc.nextInt();
		int temp=0;
		if(m!=n) {
			System.out.println("size of array a and b are not equal");
			
		}
		else
		{
		int a[]=new int[m];
		for(int i=0;i<m;i++) {
			System.out.println("please enter the element of"+ i);
		    a[i]=sc.nextInt();
		}
		int b[]=new int[n];
		for(int i=0;i<n;i++) {
			System.out.println("please enter the element of"+ i);
		    b[i]=sc.nextInt();
		}
		
		for(int i=1;i<=m;i++)
		{
			if(a[i]==b[i])
				temp++;
		}
		if(m==temp)
				System.out.println("the array elements are equal");
			else
				System.out.println("the array elements are not equal");

		}
	
}
}
