package com.marlabs.training.palindromeNumber;

import java.util.Scanner;

public class PalindromeNumber {
		public static void main(String[] args) {
			Scanner sc=new Scanner(System.in);

		    int n= sc.nextInt();
		    int temp=n;
		    int n2= 0;
		    while(n!=0) {
		    	int r=n%10;
		        n2= n2 * 10 + r;
		        n= n/10;
		    }

		    System.out.println("Reversed Number: " + n2);
		
		
		if(temp==n2)
			System.out.println("given number is palindrome:"+n2);
		else
			System.out.println("given number is not palindrome:"+n2);

			
		

	}
}


