package com.marlabs.training.StringConcat;

import java.util.Scanner;

public class StringconcatinationDemo {
		public static void main(String args[] ) throws Exception {
	        Scanner sc=new Scanner(System.in);
	        String s=sc.nextLine();
	        String s2=sc.nextLine();
	       String s3=StringconcatinationDemo.TwoString(s,s2);
	       System.out.println(s3);
	    }
	    public static String TwoString(String a,String b)
	    {
	       for(int i=0;i<b.length();i++)
	       {
	           a=a+b.charAt(i);
	       }

	       return a;


	}

}
