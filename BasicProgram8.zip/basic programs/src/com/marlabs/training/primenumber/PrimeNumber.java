package com.marlabs.training.primenumber;

import java.util.Scanner;

public class PrimeNumber {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("please enetr number");
		int n=sc.nextInt();
		int factor=0;
		for(int i=1;i<=n;i++)
		{
			if(n%i==0)
			{
				factor++;
			}
		}
		if(factor==2)
			System.out.println("given number is prime:"+n);
		else
			
		System.out.println("given number is  not prime:"+n);

	}

}
