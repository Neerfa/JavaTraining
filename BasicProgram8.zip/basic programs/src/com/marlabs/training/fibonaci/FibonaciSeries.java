package com.marlabs.training.fibonaci;

import java.util.Scanner;

public class FibonaciSeries {

	public static void main(String[] args) {
		int n=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("please enter the naumber");
		n=sc.nextInt();
		int a=0;
		int b=1;
		int c=0;
		System.out.println(a);
		System.out.println(b);
		for(int i=1;i<=n;i++) {
			c=a+b;
			a=b;
			b=c;
		System.out.println(c);
		}

	}

}
