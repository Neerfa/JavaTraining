package com.marlabs.training.swaping;

import java.util.Scanner;

public class SwapingNumber {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		System.out.println("please enter two numbers");
		int n1=sc.nextInt();
		int n2=sc.nextInt();
		System.out.println("before swaping of two number:"+n1+n2);
		n1=n1+n2;//9
		n2=n1-n2;//9-5=4
		n1=n1-n2;//9-4=5
		System.out.println("after swaping of two number:"+n1+n2);
		System.out.println("please enter two numbers");
		int num1=sc.nextInt();
		int num2=sc.nextInt();
		System.out.println("before swaping of two number:"+num1+num2);
		int temp=num1;
		num1=num2;
		num2=temp;
		System.out.println("after swaping of two number:"+num1+num2);
		

	}

}
