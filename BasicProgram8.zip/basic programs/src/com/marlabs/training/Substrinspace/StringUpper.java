package com.marlabs.training.Substrinspace;
//you just need to take string input and checks whether all the case-based characters in the string following non-casebased letters. Non-casebased letters are uppercase and all other case-based characters are lowercase.
	import java.io.*;
	import java.util.*;
	public class StringUpper {
	    public static void main(String args[] ) throws Exception {
	        Scanner sc=new Scanner(System.in);
	        String s=sc.nextLine();
	        String s2=StringUpper.Function(s);
	        System.out.println(s2);
	   }
	   public static String Function(String s3)
	   {
		   char c1[]=s3.toCharArray();
		   int flag=0;
		   for(int i=0;i<c1.length;i++)
		   {
			   if(c1[i]==' ')
				   flag++;
				   
		   }
		   String c[]=new String[flag+1];
		   int i=0;
		   while(i<c.length)
		   {
		   StringTokenizer st=new StringTokenizer(s3," ");
		   while(st.hasMoreTokens())
		   {
	        c[i]=st.nextToken();
	        System.out.println(c[i]);
	        i++;
		   }
		   }
	       int j=0;
	       while(j<c.length)
	       {
	           if(c[j].charAt(0)>='A'&&c[j].charAt(0)<='Z')
	        	   j++;
	           else
	        	   return "False";
	       }
	       return "True";
           
	   }

}
