package com.marlabs.training.palindrome;

import java.util.Scanner;

public class PalindromeNumber {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("please enter the number or string");
		String s = sc.nextLine();
		//String s1 = s;
		String s2 = "";
		//char[] c = s.toCharArray();
		int size = s.length();
		//System.out.println(s1);
		for (int i = size - 1; i >= 0; i--) {
			s2 = s2 + s.charAt(i);
		}
		System.out.println(s2);
		System.out.println(s);
		if(s.equals(s2)) {
			System.out.println("given string is palindrome");
		}
	    else {
			System.out.println("given string is not palindrome");

	    	
	    }

	}

}
