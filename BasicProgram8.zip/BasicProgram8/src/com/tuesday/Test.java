package com.tuesday;

import com.monday.Employee;
import com.wednesday.Student;

public class Test {

	public static void main(String[] args) {
		Employee ob=new Employee();
		ob.setEmpno(101);
		ob.setName("Trupti");
		ob.setDesignation("software eng");
		ob.setSalary(45000.50f);
		System.out.println(ob.getEmpno());
		System.out.println(ob.getName());
		System.out.println(ob.getSalary());
		System.out.println(ob.getDesignation());
		Student ob1=new Student();
		ob1.setRollno(102);
		ob1.setName("Madhu");
		ob1.setEmail("Madhu@gmail.com");
		System.out.println(ob1.getRollno());
		System.out.println(ob1.getName());
		System.out.println(ob1.getEmail());
	}
}

	


