package tester;
import java.util.Scanner;

import DAO.DaoDemo;
import DTO.DTODemo;
public class TestClass 
{
public static void main(String[] args) 
{
	Scanner sc=new Scanner(System.in);
DTODemo obj=new DTODemo();
obj.setId(23);
obj.setName("Afreen");
obj.setAddress("Guddad");
System.out.println(obj);

DaoDemo obj1=new DaoDemo();
obj1.saveData(obj);
}
}
