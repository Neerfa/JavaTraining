package com.marlabs.training.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="BankTable")
public class EntityDemo {
	
	@Id
	@Column(name="accno")
	int accno;
	@Column(name="name")
	String name;
	@Column(name="balance")
	String balance;
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBalance() {
		return balance;
	}
	public void setBalance(String balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "EntityDemo [accno=" + accno + ", name=" + name + ", balance=" + balance + "]";
	}
	

}
