package com.marlabs.training.Main;

import java.util.Scanner;

import com.marlabs.training.Dao.DaoDemo;
import com.marlabs.training.Entity.EntityDemo;

public class MainDemo {

	public static void main(String[] args) {
		
			Scanner sc=new Scanner(System.in);
			EntityDemo obj=new EntityDemo();
			System.out.println("please enter accno");
			int accno=sc.nextInt();
			System.out.println("please enter name");
			String name=sc.next();
			System.out.println("please enter balance");
			String balance=sc.next();
			obj.setAccno(accno);
			obj.setName(name);
			obj.setBalance(balance);
			System.out.println(obj);

			DaoDemo obj1=new DaoDemo();
			obj1.saveData(obj);
			}
}