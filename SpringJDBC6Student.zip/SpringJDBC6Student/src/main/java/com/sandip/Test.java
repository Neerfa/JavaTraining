package com.sandip;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
public class Test 
{
public static void main(String[] args) throws ClassNotFoundException, SQLException 
{
//ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
//StudentDao dao=(StudentDao)ctx.getBean("edao");
transaction();
}
private static void transaction() throws ClassNotFoundException, SQLException {
	ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationContext.xml");
	StudentDao dao=(StudentDao)ctx.getBean("edao");
System.out.println("***************************************");
System.out.println("enter 1 for TO CREATE STUDENT");
System.out.println("enter 2 for UPDATE STUDENT");
System.out.println("enter 3 for SELECT ALL STUDENT");
System.out.println("enter 4 for DELETE STUDENT");
System.out.println("enter 5 for SEARCH STUDENT");

System.out.println("***************************************");
Scanner ob = new Scanner(System.in);
System.out.println("ENETER YOUR CHOICE");
int option = ob.nextInt();
switch (option)
{
case 1:

boolean status=dao.saveEmployee(new Student(102,"Amruta","bgm"));
System.out.println(status);
transaction();
break;
case 2:
boolean status1=dao.updateEmployee(new Student(101,"Sandip","Udisa"));
System.out.println(status1);
transaction();
break;
case 3:
	List<Student> list=dao.getAllEmployees();
	for(Student e:list)
	System.out.println(e);
	transaction();
	break;
case 4:
Student s=new Student();
s.setRollno(102);
boolean status2=dao.deleteEmployee(s);
System.out.println(status2);
transaction();
break;
case 5:
	Student s1=new Student();
	s1.setRollno(101);
	Student list1=dao.searchByRollno(s1);
	System.out.println(list1);
	transaction();
	break;
	
}
}
}

