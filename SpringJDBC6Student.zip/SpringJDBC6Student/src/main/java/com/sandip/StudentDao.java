package com.sandip;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.jdbc.core.RowMapper;
public class StudentDao 
{
private JdbcTemplate jdbcTemplate;

public JdbcTemplate getJdbcTemplate() {
	return jdbcTemplate;
}

public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
	this.jdbcTemplate = jdbcTemplate;
}
public Boolean saveEmployee(final Student s)
{
	String xyz="insert into student1 values(?,?,?)";
	return jdbcTemplate.execute(xyz,new PreparedStatementCallback<Boolean>()
			{
		//@Override
		public Boolean doInPreparedStatement(PreparedStatement ps)
				throws SQLException , DataAccessException
		{
			ps.setInt(1,s.getRollno());
			ps.setString(2,s.getName());
			ps.setString(3, s.getAddress());
			return ps.execute();
		}
			});
			
}

public boolean updateEmployee(final Student s) {
	String xyz="update student1 set name=?,address=? where rollno=?";
	return jdbcTemplate.execute(xyz,new PreparedStatementCallback<Boolean>()
			{
		//@Override
		public Boolean doInPreparedStatement(PreparedStatement ps)
				throws SQLException , DataAccessException
		{
			
			ps.setString(1,s.getName());
			ps.setString(2, s.getAddress());
			ps.setInt(3,s.getRollno());
			return ps.execute();
		}
			});
			
}
public boolean deleteEmployee(final Student s) {
	String xyz="delete student1 where rollno=?";
	return jdbcTemplate.execute(xyz,new PreparedStatementCallback<Boolean>()
			{
		//@Override
		public Boolean doInPreparedStatement(PreparedStatement ps)
				throws SQLException , DataAccessException
		{
			ps.setInt(1,s.getRollno());
			return ps.execute();
		}
			});
}
			

public List<Student> getAllEmployees()
{
	return jdbcTemplate.query("select * from Student1", new ResultSetExtractor<List<Student>>()
			{
			public List<Student> extractData(ResultSet rs)throws SQLException,DataAccessException
			{
		List<Student> list=new ArrayList<Student>();
		while(rs.next())
		{
			Student e=new Student();
		e.setRollno(rs.getInt(1));
		e.setName(rs.getString(2));
		e.setAddress(rs.getString(3));
		list.add(e);
			}
		return list;
			}
			});			
			}

public Student searchByRollno(final Student s)
{
	String xyz="select * from Student1 where rollno="+s.getRollno();

	return jdbcTemplate.query(xyz, new ResultSetExtractor<Student>()
			{
			public Student extractData(ResultSet rs)throws SQLException,DataAccessException
			{
		Student list=new Student();
		Student e=new Student();
		if(rs.next())
		{	
		e.setRollno(rs.getInt(1));
		e.setName(rs.getString(2));
		e.setAddress(rs.getString(3));
			}
		return e;
			}
			});			
			}
}



