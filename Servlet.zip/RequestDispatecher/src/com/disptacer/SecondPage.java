package com.disptacer;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class SecondPage
 */
@WebServlet("/SecondPage")
public class SecondPage extends HttpServlet {
	public void  doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException
	{
		try {
		PrintWriter pw=resp.getWriter();
		resp.setContentType("text/html");
		String a= req.getParameter("t1");
		String b= req.getParameter("t2");
		String c= req.getParameter("t3");
		String d= req.getParameter("t4");
		pw.println("the name is"+a);
		pw.println("the address is"+b);
		pw.println("the phone no is"+c);
		pw.println("the email is"+d);

		}catch(Exception e) {
			e.printStackTrace();
		}
	}
}
