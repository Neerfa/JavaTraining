package com.objectArray;

import java.util.Scanner;

public class ArrayObject {
	String rollno,name,address;
	void input() {
	Scanner sc=new Scanner(System.in);
	System.out.println("please netr the name,rollnumber,address");
	rollno=sc.nextLine();
	name=sc.nextLine();
	address=sc.nextLine();
	}
	void display() {
		System.out.println("the rollno is "+rollno);
		System.out.println("the name is "+name);
		System.out.println("the address is "+address);
	}
	public static void amin(String args[]) {
		ArrayObject[] ao=new ArrayObject[3];
		for(int i=0;i<3;i++) {
			System.out.println("enter data of student no"+(i+1));
			ao[i]=new ArrayObject();
			ao[i].input();
		}
		for(int i=0;i<3;i++)
		{
			System.out.println("data of student no"+(i+1));
			ao[i].display();
		}
		}
		
		
	}



