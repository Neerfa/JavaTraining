package com.bank;

import java.util.Scanner;

public class Bankprogram10 {
	String accno;
	String name;
	String balance;
	String email;
	void input() {
		Scanner sc=new Scanner(System.in);
		System.out.println("please enter the accno,name,balance,email");
		accno=sc.nextLine();
		name=sc.nextLine();
		balance=sc.nextLine();
		email=sc.nextLine();
		}
		void display() {
			System.out.println("the rollno is "+accno);
			System.out.println("the name is "+name);
			System.out.println("the address is "+balance);
			System.out.println("the address is "+email);
			
		}
	
	
	public static void main(String[] args) {
		Bankprogram10[] b=new Bankprogram10[20];
		for(int i=0;i<20;i++) {
			System.out.println("enter data of customer no"+(i+1));
			b[i]=new Bankprogram10();
			b[i].input();
		}
		for(int i=0;i<3;i++)
		{
			System.out.println("data of customer no"+(i+1));
			b[i].display();
		}
		}
		

	}


