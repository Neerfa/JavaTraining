package com.Array;

import java.util.Scanner;

public class ArrayDemo {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("please enter 5 numbers");
		int a[]=new int[5];
		for(int i=0;i<5;i++)
			a[i]=sc.nextInt();
		System.out.println("the five numbers are");
		for(int i=0;i<5;i++)
			System.out.println(a[i]);
	}

}
