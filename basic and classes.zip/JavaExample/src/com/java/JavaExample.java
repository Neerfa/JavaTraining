package com.java;

public class JavaExample {

	public static void main(String[] args) {
		System.out.println("Hello world");
	}

}
