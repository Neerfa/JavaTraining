package com.stream;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;



public class Main {
public static void main(String[] args) {
List<Stream> student = new ArrayList<Stream>();

// Adding Students
student.add(new Stream(101, "Abhilasha", 95));
student.add(new Stream(102, "Afreen", 93));
student.add(new Stream(103, "Amruta", 90));
student.add(new Stream(104, "Samidha", 89));
student.add(new Stream(105, "Archana", 91));
List<String> studentList = student.stream().filter(s -> s.marks > 90)// filtering data
.map(s -> s.name) // fetching name
.collect(Collectors.toList()); // collecting as list
System.out.println(studentList);
}
}