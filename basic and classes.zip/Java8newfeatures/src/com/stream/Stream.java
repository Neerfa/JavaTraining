package com.stream;



public class Stream {
int id;
String name;
int marks;



public Stream(int id, String name, int marks) {
super();
this.id = id;
this.name = name;
this.marks = marks;
}



}