package com.Interface;

	
	public class Interface implements MyInterface{

		@Override
		public void existingMethod(String str) {
			// TODO Auto-generated method stub
			System.out.println("existing method"+str);
		}
		
		public static void main (String args[]) {
			Interface i=new Interface();// implementing abstract methodpublic void existingMethod(String str){System.out.println("String is: "+str);}public static void main(String[] args) {Example obj = new Example();//calling the default method of interface
		
	        i.newMethod();
	        MyInterface.anotherNewMethod();
	        i.existingMethod("hi");//calling the abstract method of interface
		}

}
