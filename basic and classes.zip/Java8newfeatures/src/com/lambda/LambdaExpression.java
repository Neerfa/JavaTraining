package com.lambda;

@FunctionalInterface
public interface LambdaExpression {

int calculate(int x);
}


