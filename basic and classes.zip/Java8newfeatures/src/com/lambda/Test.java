package com.lambda;
	class test
	{
	public static void main(String args[])
	{
	int a = 6;

	// lambda expression to define the calculate method
	LambdaExpression le = (int x)->x*x;

	// parameter passed and return type must be
	// same as defined in the prototype
	int ans = le.calculate(a);
	System.out.println(ans);
	}
	}


